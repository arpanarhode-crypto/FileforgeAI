import fs from "fs";
import path from "path";

// Define DB Types
export interface User {
  id: string;
  email: string;
  passwordHash: string;
  plan: "free" | "premium";
  createdAt: string;
}

export interface Subscription {
  id: string;
  userId: string;
  plan: "free" | "premium";
  status: "active" | "inactive";
  createdAt: string;
  expiresAt: string;
}

export interface UsageTracking {
  userId: string;
  conversionsPerTool: Record<string, number>; // daily count per tool
  ocrCount: number; // daily OCR count
  translationWords: number; // daily translation words translation
  lastResetTime: string; // ISO String
}

export interface HistoryItem {
  id: string;
  userId: string;
  fileName: string;
  toolUsed: string;
  timestamp: string;
  outputFile: string;
  status: "success" | "failed" | "pending";
}

export interface PaymentItem {
  id: string;
  userId: string;
  amount: number;
  currency: string;
  status: string;
  timestamp: string;
}

export interface ChatMessage {
  role: "user" | "model";
  content: string;
  timestamp: string;
  citations?: string[];
}

export interface ChatSession {
  id: string;
  userId: string;
  fileName: string;
  fileBase64: string;
  extractedText: string;
  title: string;
  messages: ChatMessage[];
  createdAt: string;
}

export interface SharedItem {
  id: string;
  creatorId: string;
  fileName: string;
  fileBase64: string;
  passwordHash?: string;
  expiresAt?: string;
  downloadCount: number;
  createdAt: string;
}

export interface FeedbackItem {
  id: string;
  userId: string;
  rating: number;
  message: string;
  toolUsed: string;
  createdAt: string;
}

export interface DatabaseSchema {
  users: User[];
  subscriptions: Subscription[];
  usageTracking: UsageTracking[];
  history: HistoryItem[];
  payments: PaymentItem[];
  chats?: ChatSession[];
  shares?: SharedItem[];
  feedback?: FeedbackItem[];
}

const DB_DIR = path.join(process.cwd(), "database");
const DB_FILE = path.join(DB_DIR, "db.json");

// Ensure DB Directory & File
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

const initialDb: DatabaseSchema = {
  users: [],
  subscriptions: [],
  usageTracking: [],
  history: [],
  payments: [],
  chats: [],
  shares: [],
  feedback: []
};

function readDb(): DatabaseSchema {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(initialDb, null, 2), "utf-8");
    return initialDb;
  }
  try {
    const data = fs.readFileSync(DB_FILE, "utf-8");
    return JSON.parse(data);
  } catch (e) {
    console.error("DB Corrupted, recreating database file safely.", e);
    return initialDb;
  }
}

function writeDb(data: DatabaseSchema) {
  try {
    const tempFile = `${DB_FILE}.tmp`;
    fs.writeFileSync(tempFile, JSON.stringify(data, null, 2), "utf-8");
    fs.renameSync(tempFile, DB_FILE);
  } catch (e) {
    console.error("Failed to write to local atomic DB:", e);
  }
}

// ----------------------------------------------------
// DATABASE API IMPLEMENTATIONS
// ----------------------------------------------------

import { SQLiteDB } from "./db-sqlite";

const useSQLite = process.env.USE_SQLITE === "true" || process.env.ELECTRON_ENV === "true";

const JsonDB = {
  getUsers: (): User[] => {
    return readDb().users;
  },

  getUserByEmail: (email: string): User | undefined => {
    const db = readDb();
    return db.users.find((u) => u.email.toLowerCase() === email.toLowerCase());
  },

  getUserById: (id: string): User | undefined => {
    const db = readDb();
    return db.users.find((u) => u.id === id);
  },

  createUser: (email: string, passwordHash: string): User => {
    const db = readDb();
    const newUser: User = {
      id: "usr_" + Math.random().toString(36).substring(2, 11),
      email,
      passwordHash,
      plan: "free",
      createdAt: new Date().toISOString()
    };
    db.users.push(newUser);

    // Bootstrap initial tracking
    const newTracking: UsageTracking = {
      userId: newUser.id,
      conversionsPerTool: {},
      ocrCount: 0,
      translationWords: 0,
      lastResetTime: new Date().toISOString()
    };
    db.usageTracking.push(newTracking);

    writeDb(db);
    return newUser;
  },

  upgradeUser: (userId: string, plan: "free" | "premium"): boolean => {
    const db = readDb();
    const user = db.users.find((u) => u.id === userId);
    if (!user) return false;

    user.plan = plan;

    // Update subscription too
    const existingSubIdx = db.subscriptions.findIndex((s) => s.userId === userId);
    const date = new Date();
    const expires = new Date();
    expires.setFullYear(date.getFullYear() + 1); // 1-year default active license duration

    const newSub: Subscription = {
      id: "sub_" + Math.random().toString(36).substring(2, 11),
      userId,
      plan,
      status: plan === "premium" ? "active" : "inactive",
      createdAt: date.toISOString(),
      expiresAt: expires.toISOString()
    };

    if (existingSubIdx > -1) {
      db.subscriptions[existingSubIdx] = newSub;
    } else {
      db.subscriptions.push(newSub);
    }

    writeDb(db);
    return true;
  },

  getUsage: (userId: string): UsageTracking => {
    const db = readDb();
    let tracking = db.usageTracking.find((t) => t.userId === userId);
    const now = new Date();

    if (!tracking) {
      tracking = {
        userId,
        conversionsPerTool: {},
        ocrCount: 0,
        translationWords: 0,
        lastResetTime: now.toISOString()
      };
      db.usageTracking.push(tracking);
      writeDb(db);
      return tracking;
    }

    // Check 24-hour reset logic
    const lastReset = new Date(tracking.lastResetTime);
    const msDiff = now.getTime() - lastReset.getTime();
    if (msDiff >= 24 * 60 * 60 * 1000) {
      // Reset limits
      tracking.conversionsPerTool = {};
      tracking.ocrCount = 0;
      tracking.translationWords = 0;
      tracking.lastResetTime = now.toISOString();

      // Find index & update
      const idx = db.usageTracking.findIndex((t) => t.userId === userId);
      if (idx > -1) {
        db.usageTracking[idx] = tracking;
      }
      writeDb(db);
    }

    return tracking;
  },

  incrementConversion: (userId: string, tool: string): UsageTracking => {
    const db = readDb();
    const tracking = db.usageTracking.find((t) => t.userId === userId);
    if (!tracking) {
      // Force init
      DB.getUsage(userId);
      return DB.incrementConversion(userId, tool);
    }

    // Call reset checker first
    const now = new Date();
    const lastReset = new Date(tracking.lastResetTime);
    if (now.getTime() - lastReset.getTime() >= 24 * 60 * 60 * 1000) {
      tracking.conversionsPerTool = {};
      tracking.ocrCount = 0;
      tracking.translationWords = 0;
      tracking.lastResetTime = now.toISOString();
    }

    tracking.conversionsPerTool[tool] = (tracking.conversionsPerTool[tool] || 0) + 1;
    writeDb(db);
    return tracking;
  },

  incrementOCR: (userId: string): UsageTracking => {
    const db = readDb();
    const tracking = db.usageTracking.find((t) => t.userId === userId);
    if (!tracking) {
      DB.getUsage(userId);
      return DB.incrementOCR(userId);
    }

    const now = new Date();
    const lastReset = new Date(tracking.lastResetTime);
    if (now.getTime() - lastReset.getTime() >= 24 * 60 * 60 * 1000) {
      tracking.conversionsPerTool = {};
      tracking.ocrCount = 0;
      tracking.translationWords = 0;
      tracking.lastResetTime = now.toISOString();
    }

    tracking.ocrCount = (tracking.ocrCount || 0) + 1;
    writeDb(db);
    return tracking;
  },

  incrementTranslationWords: (userId: string, wordCount: number): UsageTracking => {
    const db = readDb();
    const tracking = db.usageTracking.find((t) => t.userId === userId);
    if (!tracking) {
      DB.getUsage(userId);
      return DB.incrementTranslationWords(userId, wordCount);
    }

    const now = new Date();
    const lastReset = new Date(tracking.lastResetTime);
    if (now.getTime() - lastReset.getTime() >= 24 * 60 * 60 * 1000) {
      tracking.conversionsPerTool = {};
      tracking.ocrCount = 0;
      tracking.translationWords = 0;
      tracking.lastResetTime = now.toISOString();
    }

    tracking.translationWords = (tracking.translationWords || 0) + wordCount;
    writeDb(db);
    return tracking;
  },

  getHistory: (userId: string): HistoryItem[] => {
    const db = readDb();
    return db.history
      .filter((h) => h.userId === userId)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
  },

  addHistory: (
    userId: string,
    toolUsed: string,
    fileName: string,
    outputFile: string,
    status: "success" | "failed" | "pending"
  ): HistoryItem => {
    const db = readDb();
    const newItem: HistoryItem = {
      id: "act_" + Math.random().toString(36).substring(2, 11),
      userId,
      fileName,
      toolUsed,
      timestamp: new Date().toISOString(),
      outputFile,
      status
    };
    db.history.push(newItem);
    writeDb(db);
    return newItem;
  },

  addPayment: (userId: string, amount: number, status: string): PaymentItem => {
    const db = readDb();
    const newItem: PaymentItem = {
      id: "pay_" + Math.random().toString(36).substring(2, 11),
      userId,
      amount,
      currency: "INR",
      status,
      timestamp: new Date().toISOString()
    };
    db.payments.push(newItem);
    writeDb(db);
    return newItem;
  },

  getChats: (userId: string): ChatSession[] => {
    const db = readDb();
    if (!db.chats) db.chats = [];
    return db.chats.filter(c => c.userId === userId).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  },

  createChat: (userId: string, fileName: string, fileBase64: string, extractedText: string, title: string): ChatSession => {
    const db = readDb();
    if (!db.chats) db.chats = [];
    const newChat: ChatSession = {
      id: "cht_" + Math.random().toString(36).substring(2, 11),
      userId,
      fileName,
      fileBase64,
      extractedText,
      title,
      messages: [],
      createdAt: new Date().toISOString()
    };
    db.chats.push(newChat);
    writeDb(db);
    return newChat;
  },

  addChatMessage: (chatId: string, role: "user" | "model", content: string, citations?: string[]): ChatMessage | null => {
    const db = readDb();
    if (!db.chats) db.chats = [];
    const chat = db.chats.find(c => c.id === chatId);
    if (!chat) return null;
    const newMsg: ChatMessage = {
      role,
      content,
      timestamp: new Date().toISOString(),
      citations
    };
    chat.messages.push(newMsg);
    writeDb(db);
    return newMsg;
  },

  getShare: (id: string): SharedItem | undefined => {
    const db = readDb();
    if (!db.shares) db.shares = [];
    return db.shares.find(s => s.id === id);
  },

  createShare: (creatorId: string, fileName: string, fileBase64: string, passwordHash?: string, expiresAt?: string): SharedItem => {
    const db = readDb();
    if (!db.shares) db.shares = [];
    const newShare: SharedItem = {
      id: "sh_" + Math.random().toString(36).substring(2, 11),
      creatorId,
      fileName,
      fileBase64,
      passwordHash,
      expiresAt,
      downloadCount: 0,
      createdAt: new Date().toISOString()
    };
    db.shares.push(newShare);
    writeDb(db);
    return newShare;
  },

  incrementShareDownload: (id: string) => {
    const db = readDb();
    if (!db.shares) db.shares = [];
    const share = db.shares.find(s => s.id === id);
    if (share) {
      share.downloadCount++;
      writeDb(db);
    }
  },

  getAdminAnalytics: () => {
    const db = readDb();
    if (!db.chats) db.chats = [];
    if (!db.shares) db.shares = [];
    const users = db.users;
    const history = db.history;
    const payments = db.payments;

    // Aggregate counts
    const totalUsers = users.length;
    const premiumUsers = users.filter(u => u.plan === "premium").length;
    const freeUsers = totalUsers - premiumUsers;
    const activeSubConversions = premiumUsers;

    // Financials
    const totalRevenue = payments.reduce((acc, curr) => acc + (curr.status === "success" || curr.status === "completed" ? curr.amount : 0), 0);

    // Tool breakdown
    const toolUsageBreakdown: Record<string, number> = {};
    history.forEach(item => {
      toolUsageBreakdown[item.toolUsed] = (toolUsageBreakdown[item.toolUsed] || 0) + 1;
    });

    const failedConversionCount = history.filter(h => h.status === "failed").length;
    const totalJobs = history.length;
    
    // Usage counts
    const ocrUsageCount = history.filter(h => h.toolUsed.toLowerCase().includes("ocr")).length;
    const translationUsageCount = history.filter(h => h.toolUsed.toLowerCase().includes("translate") || h.toolUsed.toLowerCase().includes("translation")).length;
    const notesUsageCount = history.filter(h => h.toolUsed.toLowerCase().includes("notes")).length;
    const chatPdfUsageCount = history.filter(h => h.toolUsed.toLowerCase().includes("chat") || h.toolUsed.toLowerCase().includes("pdf-chat")).length;

    // Daily registrations and conversions (last 7 days rough estimate)
    const dailyRegistrations: Record<string, number> = {};
    const dailyRevenue: Record<string, number> = {};

    users.forEach(u => {
      const day = u.createdAt ? u.createdAt.substring(0, 10) : new Date().toISOString().substring(0, 10);
      dailyRegistrations[day] = (dailyRegistrations[day] || 0) + 1;
    });

    payments.forEach(p => {
      if (p.status === "success" || p.status === "completed") {
        const day = p.timestamp ? p.timestamp.substring(0, 10) : new Date().toISOString().substring(0, 10);
        dailyRevenue[day] = (dailyRevenue[day] || 0) + p.amount;
      }
    });

    return {
      totalUsers,
      premiumUsers,
      freeUsers,
      activeSubConversions,
      totalRevenue,
      failedConversionCount,
      totalJobs,
      ocrUsageCount,
      translationUsageCount,
      notesUsageCount,
      chatPdfUsageCount,
      totalShares: db.shares.length,
      totalChats: db.chats.length,
      toolUsageBreakdown,
      dailyRegistrations,
      dailyRevenue
    };
  },

  submitFeedback: (userId: string, rating: number, message: string, toolUsed: string) => {
    const db = readDb();
    if (!db.feedback) db.feedback = [];
    const id = "fb_" + Math.random().toString(36).substring(2, 11);
    const createdAt = new Date().toISOString();
    const newFeedback: FeedbackItem = {
      id,
      userId,
      rating,
      message,
      toolUsed,
      createdAt
    };
    db.feedback.push(newFeedback);
    writeDb(db);
    return newFeedback;
  },

  getFeedbackAll: () => {
    const db = readDb();
    if (!db.feedback) return [];
    return [...db.feedback].sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }
};

export const DB = useSQLite ? SQLiteDB : JsonDB;

