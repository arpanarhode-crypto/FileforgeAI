import { Request, Response, NextFunction } from "express";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { DB, User } from "./db";

const JWT_SECRET = process.env.JWT_SECRET || "FILEFORGE_SUPER_SECRET_KEY_FOR_JWT_AUTHENTICATION_V1";

export interface AuthenticatedRequest extends Request {
  user?: User;
}

export const Auth = {
  hashPassword: async (password: string): Promise<string> => {
    return bcrypt.hash(password, 10);
  },

  comparePassword: async (password: string, hash: string): Promise<boolean> => {
    return bcrypt.compare(password, hash);
  },

  generateToken: (user: User): string => {
    return jwt.sign(
      {
        id: user.id,
        email: user.email,
        plan: user.plan
      },
      JWT_SECRET,
      { expiresIn: "7d" }
    );
  },

  authenticateToken: (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];

    if (!token) {
      return res.status(401).json({ error: "Access token missing, please authenticate." });
    }

    jwt.verify(token, JWT_SECRET, (err: any, tokenPayload: any) => {
      if (err) {
        return res.status(403).json({ error: "Access token expired or invalid, please sign in again." });
      }

      const user = DB.getUserById(tokenPayload.id);
      if (!user) {
        return res.status(404).json({ error: "User profile no longer exists." });
      }

      req.user = { ...user, plan: "premium" }; // Force all accounts to be premium!
      next();
    });
  },

  // Soft auth helper that doesn't block if not logged in (allows anonymous free tier)
  optionalAuthenticateToken: (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];

    const guestIdStr = req.headers["x-guest-id"] || "guest_session";
    const fallbackGuest: User = {
      id: guestIdStr.toString().startsWith("guest_") ? guestIdStr.toString() : `guest_${guestIdStr}`,
      email: "guest@fileforge.ai",
      passwordHash: "",
      plan: "premium",
      createdAt: new Date().toISOString()
    };

    if (!token) {
      req.user = fallbackGuest;
      return next();
    }

    jwt.verify(token, JWT_SECRET, (err: any, tokenPayload: any) => {
      if (err) {
        req.user = fallbackGuest;
        return next();
      }

      const user = DB.getUserById(tokenPayload.id);
      if (user) {
        req.user = { ...user, plan: "premium" }; // Force all authenticated sessions as premium too!
      } else {
        req.user = fallbackGuest;
      }
      next();
    });
  }
};
