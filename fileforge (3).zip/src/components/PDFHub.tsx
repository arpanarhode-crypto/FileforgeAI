import { 
  FileText, 
  Layers, 
  Scissors, 
  Minimize2, 
  FileEdit, 
  Image, 
  Lock, 
  Clock, 
  Sparkles,
  ShieldAlert
} from "lucide-react";

interface PDFHubProps {
  onAddToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

export default function PDFHub({ onAddToast }: PDFHubProps) {
  const tools = [
    {
      id: "docx-to-pdf",
      name: "Word to PDF",
      desc: "Instant conversion of DOCX files into beautiful formatted PDF files.",
      icon: FileText,
      color: "from-blue-500/10 to-indigo-500/10 text-indigo-500",
      accent: "indigo",
      type: "DOCX → PDF",
    },
    {
      id: "pdf-to-docx",
      name: "PDF to Word Converter",
      desc: "Paragraph layout reconstruction and editable Word text compilation.",
      icon: FileEdit,
      color: "from-sky-500/10 to-blue-500/10 text-sky-500",
      accent: "sky",
      type: "PDF → DOCX",
    },
    {
      id: "merge-pdf",
      name: "Stitch PDFs (Merge File)",
      desc: "Merge separate sequential PDF archives into a single unified workspace document.",
      icon: Layers,
      color: "from-indigo-500/10 to-purple-500/10 text-indigo-500",
      accent: "purple",
      type: "PDF Sequential",
    },
    {
      id: "split-pdf",
      name: "Split PDF Range",
      desc: "Extract range sequences or specific selected segments with index intervals.",
      icon: Scissors,
      color: "from-teal-500/10 to-emerald-500/10 text-teal-500",
      accent: "emerald",
      type: "PDF Splitter",
    },
    {
      id: "compress-pdf",
      name: "Compress PDF Optimizer",
      desc: "Structural map optimization with tunable safe quality elements.",
      icon: Minimize2,
      color: "from-amber-500/10 to-orange-500/10 text-amber-500",
      accent: "amber",
      type: "PDF Optimizer",
    },
    {
      id: "image-to-pdf",
      name: "Image to PDF Layout",
      desc: "Package sequential PNG or JPEG image layout vectors onto a compact PDF sheet.",
      icon: Image,
      color: "from-pink-500/10 to-rose-500/10 text-pink-500",
      accent: "rose",
      type: "PNG, JPG → PDF",
    },
  ];

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-1 select-none" id="pdf-conversion-tools-container">
      {/* Workspace Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-100 dark:border-slate-800 pb-6">
        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1 text-xxs font-bold uppercase tracking-wider text-indigo-600 bg-indigo-50 dark:bg-indigo-950/40 dark:text-indigo-400 px-2.5 py-1 rounded-full">
              <Sparkles className="h-3 w-3" />
              <span>Platform Upgrade</span>
            </span>
          </div>
          <h2 className="font-display text-2xl font-bold tracking-tight text-slate-800 dark:text-slate-100" id="document-conversion-tools-title">
            Document Conversion Tools
          </h2>
          <p className="text-sm text-slate-500 dark:text-slate-400">
            Uncompromising professional document utilities under optimization for local low-latency processing.
          </p>
        </div>

        <div className="flex items-center gap-2 text-xs font-semibold text-amber-600 bg-amber-50/50 dark:bg-amber-950/20 px-3.5 py-2 rounded-xl border border-amber-100 dark:border-amber-900/30">
          <Clock className="h-4 w-4 text-amber-500" />
          <span>Coming Soon to Enterprise Tier</span>
        </div>
      </div>

      {/* Hero Notice Banner */}
      <div className="rounded-2xl border border-slate-200/80 bg-slate-50/50 p-6 dark:border-slate-800 dark:bg-slate-900/40 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3.5 max-w-2xl">
          <div className="h-10 w-10 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 flex items-center justify-center flex-shrink-0">
            <ShieldAlert className="h-5 w-5" />
          </div>
          <div className="space-y-1">
            <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-widest font-mono">
              Sandbox Compliance Assurance
            </h4>
            <p className="text-xxs leading-relaxed text-slate-550 dark:text-slate-400 font-medium">
              We are currently re-mapping our PDF compression engine to process metadata offline. This guarantees 100% data residency, zero third-party leakage, and seamless performance inside Google AI Studio preview structures without sandbox-blocking errors.
            </p>
          </div>
        </div>
        <div className="text-right flex-shrink-0 md:self-center">
          <span className="text-xxs font-mono font-bold bg-slate-200/60 dark:bg-slate-800 px-2.5 py-1 rounded text-slate-600 dark:text-slate-400">
            v2.1 Offline-First
          </span>
        </div>
      </div>

      {/* Grid of Disabled Conversion Tools */}
      <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        {tools.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.id}
              className="group relative rounded-2xl border border-slate-200 bg-white p-6 shadow-xs hover:border-slate-300 dark:border-slate-800 dark:hover:border-slate-700 dark:bg-slate-900/80 transition-all duration-300 transform hover:translate-y-[-2px] flex flex-col justify-between overflow-hidden cursor-default"
            >
              {/* Subtle background lock pattern */}
              <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                <Lock className="h-24 w-24 translate-x-12 translate-y-[-12px]" />
              </div>

              <div className="space-y-4">
                <div className="flex justify-between items-start">
                  <div className={`inline-flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr ${item.color} shadow-xs`}>
                    <Icon className="h-5.5 w-5.5" />
                  </div>
                  <span className="flex items-center gap-1 rounded-full bg-slate-100 dark:bg-slate-800 px-2.5 py-1 text-[10px] font-semibold text-slate-500 dark:text-slate-400 tracking-wide">
                    <Clock className="h-3 w-3 text-amber-500" strokeWidth={2.5} />
                    <span>Coming Soon</span>
                  </span>
                </div>

                <div className="space-y-1.5">
                  <h3 className="font-display text-base font-bold text-slate-800 dark:text-slate-100">
                    {item.name}
                  </h3>
                  <p className="text-xs text-slate-500 dark:text-slate-400 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-slate-100 dark:border-slate-800/80 flex flex-col gap-3">
                <div className="flex items-center justify-between text-[11px] font-semibold">
                  <span className="text-slate-400 dark:text-slate-500 uppercase tracking-wider font-mono">
                    {item.type}
                  </span>
                  <span className="text-amber-600 dark:text-amber-500 flex items-center gap-1 font-semibold">
                    <Lock className="h-3 w-3" /> Locked
                  </span>
                </div>
                
                <div className="w-full bg-slate-50 dark:bg-slate-950/50 rounded-lg py-1.5 px-3 border border-slate-100/60 dark:border-slate-850 text-[10px] font-semibold text-slate-550 dark:text-slate-400 text-center uppercase tracking-wide">
                  Enterprise Optimization In Progress
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
