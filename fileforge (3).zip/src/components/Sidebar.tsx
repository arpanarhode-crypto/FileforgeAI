import { 
  Home, 
  LayoutGrid, 
  FileText, 
  ScanText, 
  BrainCircuit, 
  ChevronRight,
  Info,
  Languages,
  MessageSquare,
  Award,
  BookOpen,
  Layers,
  ShieldCheck,
  History,
  Settings,
  Download,
  Database
} from "lucide-react";
import { Page } from "../types";

interface SidebarProps {
  activePage: Page;
  setActivePage: (page: Page) => void;
}

export default function Sidebar({ activePage, setActivePage }: SidebarProps) {
  const primaryMenu = [
    { id: "home", label: "Dashboard Overview", icon: Home, desc: "SaaS welcome & summary metrics" },
    { id: "pdf-tools", label: "PDF Tools Hub", icon: FileText, desc: "Word-to-PDF, join, split & shrink" },
    { id: "ocr-tools", label: "OCR Scanner Hub", icon: ScanText, desc: "Convert scans to Markdown text" },
    { id: "translation-tools", label: "Translation Studio", icon: Languages, desc: "Expressive Indian regional suite" },
  ];

  const aiWorkspaceMenu = [
    { id: "pdf-chat", label: "AI Chat Desk", icon: MessageSquare, desc: "Answer using indexed documents" },
    { id: "knowledge-base", label: "Knowledge Base", icon: Database, desc: "Embed and persist custom corpus" },
    { id: "smart-notes", label: "Notes Generator", icon: BookOpen, desc: "Generate flashcards and MCQs" },
    { id: "resume-analyzer", label: "Resume Analyzer", icon: Award, desc: "ATS grading and design review" }
  ];

  const systemMenu = [
    { id: "download-center", label: "Download Center", icon: Download, desc: "Manage generated products" },
    { id: "history", label: "Operations History", icon: History, desc: "Audit trail of previous jobs" },
    { id: "settings", label: "Settings Console", icon: Settings, desc: "Profile parameters & themes" }
  ];

  const renderNavGroup = (title: string, items: typeof primaryMenu) => (
    <div className="space-y-1.5 pt-4 first:pt-0">
      <span className="text-[10px] font-black tracking-widest text-slate-400 dark:text-slate-500 uppercase px-3">
        {title}
      </span>
      <nav className="space-y-1">
        {items.map((item) => {
          const Icon = item.icon;
          const isActive = activePage === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActivePage(item.id as Page)}
              className={`flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-xs font-semibold transition-all duration-150 text-left cursor-pointer group ${
                isActive
                  ? "bg-white text-indigo-650 shadow-sm ring-1 ring-slate-205/50 dark:bg-slate-900 dark:text-indigo-400 dark:ring-slate-800/40"
                  : "text-slate-600 hover:bg-slate-100 hover:text-slate-900 dark:text-slate-400 dark:hover:bg-slate-900/40 dark:hover:text-slate-100"
              }`}
              id={`nav-item-${item.id}`}
            >
              <Icon className={`h-4 w-4 transition-transform group-hover:scale-110 ${isActive ? "text-indigo-600 dark:text-indigo-400" : "text-slate-400 dark:text-slate-505 group-hover:text-slate-650 dark:group-hover:text-slate-400"}`} />
              <div className="flex-1 min-w-0">
                <span className="block font-bold truncate">{item.label}</span>
                <span className="block text-[10px] font-medium text-slate-400 dark:text-slate-500 group-hover:text-slate-500 dark:group-hover:text-slate-450 leading-none mt-0.5 truncate">
                  {item.desc}
                </span>
              </div>
              {isActive && <ChevronRight className="h-3.5 w-3.5 text-indigo-500 flex-shrink-0" />}
            </button>
          );
        })}
      </nav>
    </div>
  );

  const showAIWorkspace = false; // Flag to enable/disable AI Assistant Workspace public rendering

  return (
    <aside className="w-68 flex-shrink-0 border-r border-slate-250/80 bg-slate-50/70 p-4 dark:border-slate-850 dark:bg-slate-950 flex flex-col justify-between hidden md:flex">
      <div className="space-y-4 overflow-y-auto no-scrollbar max-h-[calc(100vh-120px)] pr-1">
        {renderNavGroup("Core Features", primaryMenu)}
        {showAIWorkspace && renderNavGroup("AI Assistant Workspace", aiWorkspaceMenu)}
        {renderNavGroup("Management Hub", systemMenu)}

        <div className="rounded-2xl border border-slate-200/50 bg-white p-3 dark:border-slate-855 dark:bg-slate-900 shadow-sm mt-2">
          <div className="flex gap-2 text-indigo-605 dark:text-indigo-400 mb-1">
            <Info className="h-4.5 w-4.5 flex-shrink-0 mt-0.5" />
            <h4 className="text-xs font-black uppercase tracking-wider font-display">SAAS PREVIEW</h4>
          </div>
          <p className="text-[10px] leading-relaxed text-slate-455 dark:text-slate-400 font-medium">
            FileForge runs locally on multi-threaded assemblies. Fast, private, watermark-bypassed exports.
          </p>
        </div>
      </div>

      <div className="border-t border-slate-200 pt-4 dark:border-slate-800 flex-shrink-0 mt-2">
        <div className="flex items-center gap-2 px-3">
          <div className="h-2 w-2 rounded-full bg-emerald-500 animate-pulse" />
          <span className="text-xxs font-mono text-slate-400 dark:text-slate-500 uppercase tracking-widest font-black">
            Cloud Run Engine Live
          </span>
        </div>
      </div>
    </aside>
  );
}
