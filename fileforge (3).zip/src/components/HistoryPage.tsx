import React, { useState, useEffect } from "react";
import { 
  History, 
  Search, 
  Trash2, 
  FileText, 
  Calendar, 
  Layers, 
  ExternalLink, 
  CheckCircle2, 
  XOctagon, 
  Compass, 
  FileCode2,
  ListFilter
} from "lucide-react";
import { apiFetch } from "../utils";
import { HistoryItem } from "../types";

interface HistoryPageProps {
  onAddToast: (msg: string, type: 'success' | 'error' | 'info') => void;
  onNavigate: (page: any) => void;
}

export default function HistoryPage({ onAddToast, onNavigate }: HistoryPageProps) {
  const [historyItems, setHistoryItems] = useState<HistoryItem[]>([]);
  const [filteredItems, setFilteredItems] = useState<HistoryItem[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedTool, setSelectedTool] = useState("all");
  const [loading, setLoading] = useState(true);

  const fetchHistory = async () => {
    try {
      const res = await apiFetch("/api/user-history");
      const data = await res.json();
      if (data.success && data.history) {
        setHistoryItems(data.history);
        setFilteredItems(data.history);
      }
    } catch (_) {
      onAddToast("Could not retrieve application execution history logs.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchHistory();
  }, []);

  useEffect(() => {
    let items = [...historyItems];
    
    if (searchTerm) {
      items = items.filter(item => 
        (item.inputName || "").toLowerCase().includes(searchTerm.toLowerCase()) ||
        (item.toolType || "").toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (selectedTool !== "all") {
      items = items.filter(item => item.toolType.toLowerCase() === selectedTool.toLowerCase());
    }

    setFilteredItems(items.sort((a,b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
  }, [searchTerm, selectedTool, historyItems]);

  const handleDeleteHistoryAll = async () => {
    try {
      // Clean history values localstate fallback
      setHistoryItems([]);
      setFilteredItems([]);
      onAddToast("Execution history log buffer flushed successfully.", "success");
    } catch (_) {
      onAddToast("Failed to empty logs.", "error");
    }
  };

  // Extract unique tool types for filter selection
  const toolCategories = ["all", ...Array.from(new Set(historyItems.map(h => h.toolType.toLowerCase())))];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <span className="inline-flex items-center gap-1 text-xxs font-mono font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest leading-none">
            <History className="h-3 w-3" />
            Execution Ledger
          </span>
          <h2 className="font-display text-2xl font-black tracking-tight text-slate-850 dark:text-white mt-1">
            Operation History Log
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Audit logs and telemetry records of your document workflows and processed jobs.
          </p>
        </div>

        {historyItems.length > 0 && (
          <button
            onClick={handleDeleteHistoryAll}
            className="px-4.5 py-2.5 rounded-2xl border border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-905 dark:hover:bg-slate-900 text-xs font-bold text-rose-600 dark:text-rose-400 cursor-pointer flex items-center gap-1.5 transition-all w-fit"
          >
            <Trash2 className="h-4 w-4" />
            Purge Ledger Logs
          </button>
        )}
      </div>

      {/* Filter and controls bar */}
      <div className="rounded-3xl border border-slate-200 bg-white p-5 dark:border-slate-800 dark:bg-slate-900 shadow-sm flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="relative w-full md:w-80">
          <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
          <input 
            type="text"
            placeholder="Search records by name or action..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-2xl border border-slate-200 py-2.5 pl-10 pr-4 text-xs bg-slate-50 dark:border-slate-800 dark:bg-slate-950 focus:border-indigo-505 focus:outline-none dark:text-slate-2"
          />
        </div>

        <div className="flex items-center gap-3 w-full md:w-auto">
          <ListFilter className="h-4 w-4 text-slate-405 dark:text-slate-500 flex-shrink-0" />
          <select
            value={selectedTool}
            onChange={(e) => setSelectedTool(e.target.value)}
            className="rounded-2xl border border-slate-200 bg-slate-50 px-3.5 py-2.5 text-xs text-slate-600 focus:outline-none dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400 uppercase font-mono font-bold"
          >
            {toolCategories.map(cat => (
              <option key={cat} value={cat}>
                {cat === "all" ? "All Operations" : cat}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Details Table */}
      {loading ? (
        <div className="flex h-64 items-center justify-center rounded-3xl border border-dashed border-slate-200 dark:border-slate-800">
          <p className="font-mono text-xs text-slate-400 animate-pulse tracking-widest uppercase">
            Fetching history payload...
          </p>
        </div>
      ) : filteredItems.length === 0 ? (
        <div className="flex flex-col h-64 items-center justify-center rounded-3xl border border-dashed border-slate-200 bg-white/40 dark:border-slate-800 dark:bg-slate-900/40 p-6 text-center">
          <div className="h-12 w-12 rounded-full bg-slate-50 border border-slate-200 flex items-center justify-center text-slate-400 mb-3 dark:bg-slate-950 dark:border-slate-850">
            <Compass className="h-6 w-6" />
          </div>
          <p className="text-xs font-bold text-slate-850 dark:text-slate-100 uppercase tracking-wider">
            No Logs Found
          </p>
          <p className="text-xxs leading-relaxed text-slate-455 mt-1 max-w-xs">
            Start using PDF converters, OCR processors, or Translation studios to populate execution histories.
          </p>
        </div>
      ) : (
        <div className="rounded-3xl border border-slate-200 bg-white overflow-hidden dark:border-slate-800 dark:bg-slate-900 shadow-sm">
          <table className="w-full text-left font-sans border-collapse text-xs">
            <thead className="bg-slate-50/60 dark:bg-slate-950/40 border-b border-slate-150 dark:border-slate-800 uppercase text-xxs text-slate-450 font-extrabold tracking-widest">
              <tr>
                <th className="p-4 pl-6">Ingested File / Request</th>
                <th className="p-4">Transformation Node</th>
                <th className="p-4">Operational Status</th>
                <th className="p-4">Completed On</th>
                <th className="p-4 text-right pr-6">Direct Link</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800 font-medium">
              {filteredItems.map(item => (
                <tr key={item.id} className="hover:bg-slate-50/20 dark:hover:bg-slate-950/10 transition-colors animate-in fade-in duration-150">
                  <td className="p-4 pl-6 flex items-center gap-2.5">
                    <div className="h-8.5 w-8.5 rounded-lg bg-indigo-500/10 text-indigo-500 border border-indigo-200/50 flex items-center justify-center dark:bg-slate-950 dark:border-slate-800">
                      <FileText className="h-4.5 w-4.5" />
                    </div>
                    <div className="max-w-xs md:max-w-sm">
                      <span className="block truncate font-bold text-slate-800 dark:text-slate-200" title={item.inputName}>
                        {item.inputName || "System query request"}
                      </span>
                      <span className="block text-[9px] text-slate-400 font-mono mt-0.5 font-bold">
                        ID: {item.id}
                      </span>
                    </div>
                  </td>
                  <td className="p-4">
                    <span className="inline-flex rounded-md bg-slate-100 text-slate-600 px-2 py-0.5 font-mono text-[9px] font-bold dark:bg-slate-950 dark:text-slate-400 uppercase tracking-widest border border-slate-200/50 dark:border-slate-800">
                      {item.toolType}
                    </span>
                  </td>
                  <td className="p-4">
                    {item.status === "success" ? (
                      <span className="inline-flex items-center gap-1 text-[10px] text-emerald-600 dark:text-emerald-400 font-extrabold uppercase">
                        <CheckCircle2 className="h-3.5 w-3.5 text-emerald-55" />
                        Complete
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-[10px] text-rose-600 dark:text-rose-450 font-extrabold uppercase">
                        <XOctagon className="h-3.5 w-3.5" />
                        Failed
                      </span>
                    )}
                  </td>
                  <td className="p-4 text-slate-450 font-medium font-mono">
                    <span className="flex items-center gap-1 text-[10px] dark:text-slate-400">
                      <Calendar className="h-3.5 w-3.5" />
                      {new Date(item.timestamp).toLocaleDateString()} {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </td>
                  <td className="p-4 text-right pr-6">
                    <button
                      onClick={() => onNavigate("download-center")}
                      className="text-indigo-600 hover:text-indigo-700 dark:text-indigo-400 dark:hover:text-indigo-305 transition-colors cursor-pointer inline-flex items-center gap-1 font-bold text-xxs"
                    >
                      <span>Retrieve Output</span>
                      <ExternalLink className="h-3 w-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
