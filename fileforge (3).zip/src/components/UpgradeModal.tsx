import React, { useState } from "react";
import { 
  X, 
  Sparkles, 
  CheckCircle2, 
  Share2, 
  ShieldCheck, 
  Mail, 
  Loader,
  Cloud,
  Users,
  Cpu,
  Mic,
  Eye,
  Briefcase,
  Settings as SettingsIcon
} from "lucide-react";

interface UpgradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpgradeSuccess?: (newPlan: 'premium') => void;
}

const comingSoonFeatures = [
  { name: "Cloud Sync", desc: "Sync your files and history across all your devices securely.", icon: Cloud },
  { name: "Team Workspace", desc: "Collaborate with colleagues on shared document collections.", icon: Users },
  { name: "Local AI Models", desc: "Run your private LLMs offline via Ollama and llama.cpp integrations.", icon: Cpu },
  { name: "AI Voice Assistant", desc: "Ask questions and get audio summaries via deep neural TTS.", icon: Mic },
  { name: "Advanced OCR", desc: "Detect and extract tables, charts, and mathematical matrices.", icon: Eye },
  { name: "Enterprise Tools", desc: "Integrate SSO, audit logs, and directory provisioning systems.", icon: Briefcase },
  { name: "Smart Automation", desc: "Create visual recipes to chain document tasks sequentially.", icon: SettingsIcon }
];

export default function UpgradeModal({ isOpen, onClose }: UpgradeModalProps) {
  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);

  if (!isOpen) return null;

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    
    // Simulate subscribing to early access waitlist
    setTimeout(() => {
      setSuccess(true);
      setLoading(false);
    }, 1200);
  };

  const currentFreeFeatures = [
    { title: "Infinite Document Conversions", desc: "Convert unlimited Word/PDF/Image transfers without watermark restrictions." },
    { title: "High-Fidelity Optical OCR", desc: "Unlimited scanned pages & slanted images text extractions." },
    { title: "Multilingual AI Translation", desc: "Convert endless documents across major Indian languages." },
    { title: "AI Document Workspace", desc: "Deep document summaries, resume ATS reviews, and smart notes generator." }
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-200">
      
      {/* Central modal card */}
      <div className="relative w-full max-w-2xl overflow-hidden bg-white dark:bg-[#0c101c] border border-slate-200 dark:border-slate-800 rounded-3xl p-6 md:p-8 shadow-2xl animate-in fade-in zoom-in-95 duration-200 text-slate-900 dark:text-slate-100 flex flex-col max-h-[90vh]">
        
        {/* Absolute design accents */}
        <div className="absolute top-0 right-0 h-40 w-40 bg-indigo-500/10 dark:bg-indigo-400/5 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 h-40 w-40 bg-violet-500/10 dark:bg-violet-400/5 rounded-full blur-3xl pointer-events-none" />

        {/* Close button */}
        <button 
          onClick={onClose}
          className="absolute top-5 right-5 h-8 w-8 flex items-center justify-center rounded-xl bg-slate-50 border border-slate-150 hover:bg-slate-100 text-slate-500 dark:bg-slate-950 dark:border-slate-900 dark:hover:bg-[#151a2d] dark:text-slate-400 cursor-pointer z-10"
          title="Dismiss Modal"
        >
          <X className="h-4 w-4" />
        </button>

        {/* Header frame */}
        <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-850">
          <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gradient-to-tr from-indigo-505 to-violet-500 text-white shadow-md">
            <Sparkles className="h-6 w-6 animate-pulse" />
          </div>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-widest text-indigo-650 dark:text-indigo-400">
              Early Access Free Version
            </span>
            <h3 className="text-lg font-black tracking-tight font-display text-slate-850 dark:text-white leading-tight">
              FileForge AI Workspace Roadmap
            </h3>
          </div>
        </div>

        {/* Scrollable contents */}
        <div className="flex-1 overflow-y-auto py-5 space-y-6 pr-1">
          <div>
            <p className="text-xs text-slate-550 dark:text-slate-400 leading-relaxed font-semibold">
              Thank you for being part of our early access feedback program. To help unleash design and technical workflows, <span className="text-indigo-600 dark:text-indigo-400 font-bold">100% of premium systems are currently completely unlocked and unlimited!</span> No credit cards, subscriptions, or payments are required.
            </p>
          </div>

          {/* Unlocked Features list */}
          <div className="space-y-3">
            <h4 className="text-xxs font-extrabold uppercase tracking-wider text-slate-450 dark:text-slate-500">
              Active Unrestricted Tools
            </h4>
            <div className="grid gap-3 sm:grid-cols-2">
              {currentFreeFeatures.map((item, index) => (
                <div key={index} className="flex gap-2.5 items-start p-3 rounded-xl border border-slate-100 bg-slate-50/50 dark:border-slate-850 dark:bg-slate-950/30">
                  <div className="mt-0.5 flex h-4.5 w-4.5 items-center justify-center rounded-full bg-emerald-100 text-emerald-800 dark:bg-emerald-950/50 dark:text-emerald-400 flex-shrink-0">
                    <CheckCircle2 className="h-3 w-3" />
                  </div>
                  <div>
                    <h5 className="text-xs font-black text-slate-850 dark:text-slate-200">
                      {item.title}
                    </h5>
                    <p className="text-xxs text-slate-400 dark:text-slate-500 leading-normal mt-0.5">
                      {item.desc}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Roadmap upcoming cards */}
          <div className="space-y-3">
            <h4 className="text-xxs font-extrabold uppercase tracking-wider text-slate-450 dark:text-slate-500">
              More Features Coming Soon
            </h4>
            <div className="grid gap-2.5 grid-cols-2 sm:grid-cols-3">
              {comingSoonFeatures.map((feat, idx) => {
                const Icon = feat.icon;
                return (
                  <div key={idx} className="p-3 rounded-xl border border-dashed border-slate-200 bg-[#fafbfc]/30 dark:border-slate-800/80 dark:bg-slate-900/10">
                    <div className="h-6 w-6 flex items-center justify-center rounded-md bg-slate-100 dark:bg-slate-850 text-slate-500 dark:text-slate-400 mb-2">
                      <Icon className="h-3.5 w-3.5" />
                    </div>
                    <span className="block text-xxs font-bold text-slate-800 dark:text-slate-205">{feat.name}</span>
                    <span className="block text-[9px] text-slate-400 dark:text-slate-500 leading-tight mt-0.5 truncate" title={feat.desc}>{feat.desc}</span>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer waitlist subscriber or success element */}
        <div className="pt-4 border-t border-slate-100 dark:border-slate-850 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="text-left">
            <span className="block text-[9px] font-extrabold uppercase tracking-widest text-slate-400 dark:text-slate-500 pl-0.5 leading-none">
              Stay in the Loop
            </span>
            <span className="block text-xxs text-slate-500 dark:text-slate-400 font-medium mt-1">
              Be notified instantly when future updates rollout!
            </span>
          </div>

          {!success ? (
            <form onSubmit={handleSubscribe} className="flex gap-2 w-full sm:w-auto">
              <div className="relative flex-1 sm:w-48">
                <Mail className="absolute left-3 top-2.5 h-3.5 w-3.5 text-slate-400 pointer-events-none" />
                <input 
                  type="email" 
                  required
                  placeholder="name@company.com" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full text-xxs p-2 pl-9 rounded-xl border border-slate-200 bg-slate-50 focus:border-indigo-500 focus:outline-none dark:border-slate-850 dark:bg-slate-950 dark:text-slate-200"
                />
              </div>
              <button 
                type="submit" 
                disabled={loading}
                className="rounded-xl bg-indigo-600 hover:bg-indigo-700 hover:brightness-105 active:scale-95 text-white shadow flex items-center gap-1.5 p-2 px-4 text-xxs font-bold disabled:opacity-50 transition-all cursor-pointer flex-shrink-0"
              >
                {loading ? <Loader className="h-3 w-3 animate-spin" /> : <Share2 className="h-3 w-3" />}
                <span>Subscribe</span>
              </button>
            </form>
          ) : (
            <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 text-xxs font-extrabold uppercase tracking-widest bg-emerald-50 dark:bg-emerald-950/35 border border-emerald-100 dark:border-emerald-900 rounded-xl px-4 py-2">
              <CheckCircle2 className="h-4 w-4" />
              <span>You are on the list!</span>
            </div>
          )}
        </div>

      </div>
    </div>
  );
}
