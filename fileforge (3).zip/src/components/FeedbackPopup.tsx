import React, { useState, useEffect } from "react";
import { Star, X, CheckSquare, Sparkles, AlertCircle } from "lucide-react";
import { apiFetch } from "../utils";

interface FeedbackPopupProps {
  isOpen: boolean;
  onClose: () => void;
  toolUsed: string;
  onAddToast: (msg: string, type: "success" | "error" | "info") => void;
}

export default function FeedbackPopup({ 
  isOpen, 
  onClose, 
  toolUsed, 
  onAddToast 
}: FeedbackPopupProps) {
  const [rating, setRating] = useState<number>(0);
  const [hoverRating, setHoverRating] = useState<number>(0);
  const [suggestion, setSuggestion] = useState<string>("");
  const [selectedImprovement, setSelectedImprovement] = useState<string[]>([]);
  const [submitting, setSubmitting] = useState<boolean>(false);

  const improvements = ["Speed", "Output Quality", "Interface", "File Formats", "Error Handling", "AI Grounding"];

  useEffect(() => {
    if (isOpen) {
      setRating(0);
      setHoverRating(0);
      setSuggestion("");
      setSelectedImprovement([]);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const toggleImprovement = (tag: string) => {
    setSelectedImprovement(prev => 
      prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]
    );
  };

  const handleSkip = () => {
    // skipped -> wait 3 days
    localStorage.setItem("fileforge-last-feedback-skipped", new Date().toISOString());
    onClose();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) {
      onAddToast("Please pick a star rating first!", "error");
      return;
    }

    setSubmitting(true);
    try {
      const compiledMsg = [
        `[Improve: ${selectedImprovement.join(", ") || "None"}]`,
        suggestion
      ].filter(Boolean).join(" - ");

      const res = await apiFetch("/api/feedback", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          rating,
          message: compiledMsg,
          toolUsed
        })
      });

      if (res.ok) {
        onAddToast("Thank you for your valuable feedback!", "success");
        // submitted -> wait 7 days
        localStorage.setItem("fileforge-last-feedback-submitted", new Date().toISOString());
        
        // Remove skips cooldown to reset skip loop cleanly
        localStorage.removeItem("fileforge-last-feedback-skipped");
        onClose();
      } else {
        throw new Error();
      }
    } catch (_) {
      onAddToast("Could not post feedback, saved locally.", "info");
      // Fallback local save in case of offline processing (fully supporting offline focus)
      localStorage.setItem("fileforge-last-feedback-submitted", new Date().toISOString());
      onClose();
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-905/65 backdrop-blur-sm dark:bg-black/70 animate-in fade-in duration-200">
      <div className="relative w-full max-w-md overflow-hidden rounded-3xl bg-white border border-slate-100 p-6 shadow-2xl dark:bg-slate-900 dark:border-slate-800 animate-in zoom-in-95 duration-200" id="feedback-popup-card">
        {/* Glow decoration */}
        <div className="absolute top-0 right-0 -mr-16 -mt-16 h-36 w-36 rounded-full bg-indigo-500/10 blur-3xl" />
        
        <header className="flex items-start justify-between">
          <div className="space-y-1">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-indigo-50 px-2.5 py-0.5 text-[10px] font-bold text-indigo-600 dark:bg-indigo-950/45 dark:text-indigo-400">
              <Sparkles className="h-3 w-3" />
              SaaS Smart Feedback
            </span>
            <h3 className="text-sm font-semibold tracking-tight text-slate-800 dark:text-slate-100">
              How was your experience?
            </h3>
            <p className="text-xxs text-slate-455 dark:text-slate-400 leading-snug">
              You recently used the <strong className="text-indigo-600 dark:text-indigo-400 font-mono text-[10px]">{toolUsed}</strong> tool. Let us know how it fell!
            </p>
          </div>
          <button
            onClick={handleSkip}
            className="rounded-xl border border-slate-100 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800 cursor-pointer p-1.5 transition-colors"
          >
            <X className="h-4 w-4 text-slate-400" />
          </button>
        </header>

        <form onSubmit={handleSubmit} className="mt-5 space-y-4">
          {/* Interactive Star Picker */}
          <div className="space-y-1.5">
            <label className="text-xxs font-black uppercase tracking-wider text-slate-400 pl-1">
              Select rating
            </label>
            <div className="flex items-center gap-2 py-1 justify-center rounded-2xl bg-slate-50/50 border border-slate-10 border-dashed dark:bg-slate-950/20 dark:border-slate-800">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  key={star}
                  type="button"
                  onClick={() => setRating(star)}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  className="p-1 cursor-pointer transition-transform hover:scale-125 focus:outline-none"
                  title={`${star} Stars`}
                >
                  <Star 
                    className={`h-7 w-7 transition-colors duration-150 ${
                      star <= (hoverRating || rating)
                        ? "fill-amber-400 text-amber-400"
                        : "text-slate-300 dark:text-slate-700"
                    }`}
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Quick Tags selector */}
          {rating > 0 && rating <= 3 && (
            <div className="space-y-1.5 animate-in slide-in-from-top-2 duration-200">
              <label className="text-xxs font-black uppercase tracking-wider text-slate-400 pl-1 flex items-center gap-1">
                <AlertCircle className="h-3 w-3 text-indigo-500" />
                What can we improve?
              </label>
              <div className="flex flex-wrap gap-1.5">
                {improvements.map((tag) => {
                  const isSelected = selectedImprovement.includes(tag);
                  return (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => toggleImprovement(tag)}
                      className={`rounded-xl px-2.5 py-1 text-xxs font-semibold cursor-pointer transition-all border ${
                        isSelected 
                          ? "bg-indigo-600 text-white border-indigo-600 shadow-sm"
                          : "bg-slate-50 text-slate-600 border-slate-200/80 hover:bg-slate-100 dark:bg-slate-950 dark:text-slate-400 dark:border-slate-800"
                      }`}
                    >
                      {tag}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Additional suggestions input */}
          <div className="space-y-1.5">
            <label className="text-xxs font-black uppercase tracking-wider text-slate-400 pl-1">
              Suggestions & Comments
            </label>
            <textarea
              value={suggestion}
              onChange={(e) => setSuggestion(e.target.value)}
              placeholder="Tell us what you liked, or where we fell short..."
              rows={3}
              className="w-full rounded-2xl border border-slate-200 px-3.5 py-2.5 text-xs bg-slate-50/50 text-slate-800 focus:border-indigo-500 focus:outline-none dark:border-slate-850 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>

          <footer className="flex items-center gap-3 border-t border-slate-100/80 pt-3.5 dark:border-slate-800/80">
            <button
              type="button"
              onClick={handleSkip}
              className="flex-1 rounded-2xl border border-slate-200/85 bg-white py-2.5 text-xs font-bold text-slate-600 hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-450 dark:hover:bg-slate-900 cursor-pointer transition-all"
            >
              Skip
            </button>
            <button
              type="submit"
              disabled={submitting || rating === 0}
              className={`flex-1 rounded-2xl py-2.5 text-xs font-bold text-white shadow-md transition-all flex items-center justify-center gap-1.5 ${
                rating === 0 
                  ? "bg-slate-300 dark:bg-slate-800 text-slate-400 dark:text-slate-500 cursor-not-allowed shadow-none" 
                  : "bg-gradient-to-r from-indigo-605 to-violet-500 hover:from-indigo-700 hover:to-violet-600 cursor-pointer active:scale-97"
              }`}
            >
              {submitting ? "Saving..." : "Submit feedback"}
            </button>
          </footer>
        </form>
      </div>
    </div>
  );
}
