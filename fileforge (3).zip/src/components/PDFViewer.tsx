import {
  Eye,
  Download,
  Trash2,
  Maximize,
  Sparkles,
  Wand2,
} from "lucide-react";

import { UploadedFile } from "../types";
import { useEffect, useMemo, useState } from "react";

interface PDFViewerProps {
  file: UploadedFile;
  onClear: () => void;
  onQuickAction?: (action: "ai" | "ocr") => void;
}

export default function PDFViewer({
  file,
  onClear,
  onQuickAction,
}: PDFViewerProps) {
  const [blobUrl, setBlobUrl] = useState<string | null>(null);

  /**
   * Generate lightweight blob URL ONLY ONCE
   * Prevents AI Studio freezing from repeated huge base64 parsing
   */
  useEffect(() => {
    if (file.resultUrl) {
      setBlobUrl(file.resultUrl);
      return;
    }

    try {
      const base64Data = file.resultBase64 || file.base64;

      const byteCharacters = atob(base64Data);

      const byteNumbers = new Uint8Array(byteCharacters.length);

      for (let i = 0; i < byteCharacters.length; i++) {
        byteNumbers[i] = byteCharacters.charCodeAt(i);
      }

      const blob = new Blob([byteNumbers], {
        type: "application/pdf",
      });

      const url = URL.createObjectURL(blob);

      setBlobUrl(url);

      return () => {
        URL.revokeObjectURL(url);
      };
    } catch (err) {
      console.error("Blob creation failed:", err);
    }
  }, [file]);

  /**
   * Lightweight embed source
   */
  const embedSource = useMemo(() => {
    if (blobUrl) return blobUrl;

    return `data:application/pdf;base64,${
      file.resultBase64 || file.base64
    }`;
  }, [blobUrl, file]);

  /**
   * Download handler
   */
  const handleDownload = () => {
    try {
      const link = document.createElement("a");

      if (file.resultUrl) {
        link.href = `${file.resultUrl}?download=true`;
      } else {
        link.href = embedSource;
      }

      link.download = file.resultName || file.name;

      document.body.appendChild(link);

      link.click();

      document.body.removeChild(link);
    } catch (err) {
      console.error("Download failed:", err);
    }
  };

  /**
   * Fullscreen handler
   */
  const handleFullScreen = () => {
    try {
      window.open(embedSource, "_blank", "noopener,noreferrer");
    } catch (err) {
      console.error("Fullscreen open failed:", err);
    }
  };

  return (
    <div className="rounded-2xl border border-slate-200 bg-white shadow-sm dark:border-slate-800 dark:bg-slate-900 overflow-hidden flex flex-col h-[600px]">

      {/* HEADER */}
      <div className="flex items-center justify-between border-b border-slate-100 bg-slate-50 px-4 py-3 dark:border-slate-800 dark:bg-slate-950/70">

        <div className="flex items-center gap-2.5 min-w-0">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-indigo-50 text-indigo-600 dark:bg-indigo-950/50 dark:text-indigo-400">
            <Eye className="h-4.5 w-4.5" />
          </div>

          <div className="min-w-0">
            <h3 className="text-xs font-semibold text-slate-800 dark:text-slate-200 truncate">
              {file.resultName || file.name}
            </h3>

            <p className="text-xxs font-mono text-slate-400 dark:text-slate-500">
              {(file.size / (1024 * 1024)).toFixed(2)} MB
            </p>
          </div>
        </div>

        {/* ACTIONS */}
        <div className="flex items-center gap-1.5 flex-shrink-0">

          {onQuickAction && (
            <>
              <button
                onClick={() => onQuickAction("ai")}
                className="flex items-center gap-1 rounded-lg bg-indigo-50 px-2.5 py-1 text-xxs font-semibold text-indigo-600 hover:bg-indigo-100 dark:bg-indigo-950/50 dark:text-indigo-400"
              >
                <Sparkles className="h-3 w-3" />
                <span>Summarize</span>
              </button>

              <button
                onClick={() => onQuickAction("ocr")}
                className="flex items-center gap-1 rounded-lg bg-slate-100 px-2.5 py-1 text-xxs font-semibold text-slate-700 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300"
              >
                <Wand2 className="h-3 w-3" />
                <span>Extract</span>
              </button>
            </>
          )}

          <div className="h-4 w-[1px] bg-slate-200 dark:bg-slate-800 mx-1.5" />

          <button
            onClick={handleFullScreen}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <Maximize className="h-4 w-4" />
          </button>

          <button
            onClick={handleDownload}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-slate-500 hover:bg-slate-100 dark:hover:bg-slate-800"
          >
            <Download className="h-4 w-4" />
          </button>

          <button
            onClick={onClear}
            className="flex h-8 w-8 items-center justify-center rounded-lg text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/40"
          >
            <Trash2 className="h-4 w-4" />
          </button>
        </div>
      </div>

      {/* SANDBOX NOTICE */}
      {window.self !== window.top && (
        <div className="bg-slate-50 border-b border-slate-200 px-4 py-2 text-xs text-slate-600 dark:bg-slate-900 dark:border-slate-800 dark:text-slate-300 flex items-center justify-between">

          <span>
            Embedded preview may be limited inside AI Studio sandbox.
          </span>

          <button
            onClick={handleFullScreen}
            className="rounded-lg bg-indigo-600 hover:bg-indigo-700 text-white px-3 py-1 text-xxs font-semibold"
          >
            Open Fullscreen
          </button>
        </div>
      )}

      {/* PDF VIEWER */}
      <div className="flex-1 bg-slate-100 dark:bg-slate-950 relative">

        {embedSource ? (
          <iframe
            src={embedSource}
            title="PDF Viewer"
            className="absolute inset-0 w-full h-full border-0"
            loading="lazy"
          />
        ) : (
          <div className="absolute inset-0 flex items-center justify-center text-sm text-slate-500">
            Failed to load PDF preview
          </div>
        )}
      </div>
    </div>
  );
}