import React, { useState } from "react";
import { 
  BookOpen, 
  Search, 
  Database, 
  FileText, 
  Sparkles, 
  ArrowRight, 
  Cpu, 
  Plus, 
  HardDrive, 
  CheckCircle2, 
  Layers,
  Bot
} from "lucide-react";
import { UploadedFile } from "../types";
import FileUploader from "./FileUploader";

interface KnowledgeBaseProps {
  onAddToast: (msg: string, type: 'success' | 'error' | 'info') => void;
}

interface CorpusDocument {
  id: string;
  name: string;
  size: string;
  textExtracted: string;
  vectors: number;
  status: "ready" | "indexing";
  createdAt: string;
}

export default function KnowledgeBase({ onAddToast }: KnowledgeBaseProps) {
  const [corpus, setCorpus] = useState<CorpusDocument[]>([
    {
      id: "doc-01",
      name: "FileForge_SaaS_User_Guide.pdf",
      size: "2.4 MB",
      textExtracted: "FileForge provides advanced PDF merge, splitting, AI OCR, and multi-lingual Indian regional translations in clean pipeline forms.",
      vectors: 124,
      status: "ready",
      createdAt: "2026-05-18"
    },
    {
      id: "doc-02",
      name: "SaaS_Privacy_Framework.docx",
      size: "450 KB",
      textExtracted: "This document reviews user data integrity, client-side encryption caches, and local sqlite instances for electron-builder offline tools.",
      vectors: 45,
      status: "ready",
      createdAt: "2026-05-20"
    }
  ]);

  const [searchQuery, setSearchQuery] = useState("");
  const [searchResults, setSearchResults] = useState<string[]>([]);
  const [isSearching, setIsSearching] = useState(false);

  const handleUploadComplete = (file: UploadedFile) => {
    onAddToast(`Uploaded "${file.name}" to RAG Context!`, "info");
    
    // Simulate text extraction & Gemini Embeddings vector indexing
    const newDoc: CorpusDocument = {
      id: "doc-" + Math.random().toString(36).substring(2, 9),
      name: file.name,
      size: `${(file.size / 1024).toFixed(1)} KB`,
      textExtracted: `Indexed corpus from: ${file.name}. Grounded OCR and text strings ready for semantic match queries.`,
      vectors: Math.floor(Math.random() * 80) + 30,
      status: "indexing",
      createdAt: new Date().toISOString().substring(0, 10)
    };

    setCorpus(prev => [newDoc, ...prev]);

    setTimeout(() => {
      setCorpus(prev => 
        prev.map(d => d.id === newDoc.id ? { ...d, status: "ready" } : d)
      );
      onAddToast(`Successfully indexed "${file.name}" into ChromaDB with Gemini Embeddings!`, "success");
    }, 2800);
  };

  const handleSemanticSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setIsSearching(true);
    setSearchResults([]);

    setTimeout(() => {
      const match = corpus.filter(doc => 
        doc.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        doc.textExtracted.toLowerCase().includes(searchQuery.toLowerCase())
      );

      if (match.length > 0) {
        setSearchResults(match.map(doc => `[Match 94%] ${doc.name}: "...${doc.textExtracted.substring(0, 90)}..."`));
        onAddToast(`Semantic retriever returned ${match.length} relevant context sentences.`, "success");
      } else {
        setSearchResults([`[Match 41%] Semantic search found no high-threshold context blocks. Defaulting to general LLM weights.`]);
        onAddToast("Finished semantic grounding scan.", "info");
      }
      setIsSearching(false);
    }, 900);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <span className="inline-flex items-center gap-1 text-xxs font-mono font-bold text-indigo-600 dark:text-indigo-400 uppercase tracking-widest leading-none">
            <Bot className="h-3 w-3" />
            AI RAG Platform
          </span>
          <h2 className="font-display text-2xl font-black tracking-tight text-slate-850 dark:text-white mt-1">
            Enterprise Knowledge Base
          </h2>
          <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
            Build context indexes from PDFs and images to empower your custom AI chatbot with direct factual grounding.
          </p>
        </div>
      </div>

      {/* Grid: Upload & Search */}
      <div className="grid gap-6 md:grid-cols-12">
        {/* Left pane: File uploader indexing */}
        <div className="md:col-span-12 lg:col-span-7 space-y-6">
          <div className="rounded-3xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 -mr-12 -mt-12 w-28 h-28 bg-indigo-500/5 rounded-full blur-2xl" />
            <h3 className="text-xs font-extrabold uppercase text-slate-400 dark:text-slate-500 tracking-wider mb-4 flex items-center gap-2">
              <Plus className="h-4 w-4 text-indigo-500" />
              Index New Documents
            </h3>
            
            <FileUploader 
              onFileLoaded={handleUploadComplete}
              allowedTypes={[".pdf", ".docx", ".txt"]}
              maxSizeMB={20}
              helperText="Drag & drop PDF, Word, or text to feed your corpus..."
            />
          </div>

          {/* Connected Documents Area */}
          <div className="rounded-3xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-sm">
            <h3 className="text-xs font-extrabold uppercase text-slate-400 dark:text-slate-500 tracking-wider mb-4 flex items-center gap-2">
              <Database className="h-4 w-4 text-slate-400" />
              Corporate Corpus Document Pool ({corpus.length})
            </h3>

            <div className="divide-y divide-slate-100 dark:divide-slate-800">
              {corpus.map(doc => (
                <div key={doc.id} className="py-4 first:pt-0 last:pb-0 flex items-start gap-3 justify-between animate-in fade-in duration-300">
                  <div className="flex gap-3 items-start">
                    <div className="mt-1 flex h-9 w-9 items-center justify-center rounded-xl bg-slate-50 dark:bg-slate-950 text-indigo-500 border border-slate-200/50 dark:border-slate-800">
                      <FileText className="h-5 w-5" />
                    </div>
                    <div>
                      <h4 className="text-xs font-bold text-slate-800 dark:text-slate-100 flex items-center gap-2">
                        {doc.name}
                        <span className="text-[10px] text-slate-400 font-medium font-mono">({doc.size})</span>
                      </h4>
                      <p className="text-[10px] text-slate-400 dark:text-slate-500 truncate max-w-[320px] md:max-w-[450px] mt-0.5 font-medium italic">
                        "{doc.textExtracted}"
                      </p>
                      <div className="flex items-center gap-4 mt-2">
                        <span className="text-[9px] font-mono text-slate-450 dark:text-slate-500 flex items-center gap-1 font-bold">
                          <HardDrive className="h-3 w-3" />
                          {doc.vectors} Vector Embeddings
                        </span>
                        <span className="text-[9px] font-mono text-slate-400 dark:text-slate-500">
                          Added: {doc.createdAt}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div>
                    {doc.status === "indexing" ? (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[9px] font-extrabold bg-indigo-50 text-indigo-600 dark:bg-indigo-950/40 dark:text-indigo-400 border border-indigo-100/50 dark:border-indigo-900/40 animate-pulse">
                        <Cpu className="h-3 w-3 animate-spin" />
                        INDEXING
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-[9px] font-extrabold bg-emerald-50 text-emerald-600 dark:bg-emerald-950/40 dark:text-emerald-400 border border-emerald-100/50 dark:border-emerald-900/40">
                        <CheckCircle2 className="h-3 w-3 text-emerald-55" />
                        SYNCED
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right pane: Playground search */}
        <div className="md:col-span-12 lg:col-span-5 space-y-6">
          <div className="rounded-3xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-sm relative overflow-hidden">
            <div className="absolute top-0 right-0 -mr-12 -mt-12 w-28 h-28 bg-emerald-500/5 rounded-full blur-2xl" />
            
            <h3 className="text-xs font-extrabold uppercase text-slate-400 dark:text-slate-500 tracking-wider mb-4 flex items-center gap-2">
              <Search className="h-4 w-4 text-emerald-500" />
              Grounded Semantic Playground
            </h3>

            <p className="text-[10px] leading-relaxed text-slate-500 dark:text-slate-400 mb-4">
              Test your semantic retrieval queries instantly using cosine distance matching against the indexed vector pool.
            </p>

            <form onSubmit={handleSemanticSearch} className="flex gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-3 h-4 w-4 text-slate-400" />
                <input 
                  type="text"
                  placeholder="Enter semantic query e.g., translations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full rounded-2xl border border-slate-200 py-2.5 pl-10 pr-4 text-xs bg-slate-50 dark:border-slate-800 dark:bg-slate-950 focus:border-indigo-505 focus:outline-none dark:text-slate-2"
                />
              </div>
              <button
                type="submit"
                disabled={isSearching || !searchQuery.trim()}
                className="rounded-2xl bg-indigo-600 hover:bg-indigo-700 font-bold text-xs text-white px-4 cursor-pointer active:scale-95 transition-all disabled:brightness-75"
              >
                {isSearching ? "Matching..." : "Query"}
              </button>
            </form>

            {searchResults.length > 0 && (
              <div className="mt-4 p-3 bg-slate-50 dark:bg-slate-950 border border-slate-150 dark:border-slate-850 rounded-2xl space-y-2 animate-in slide-in-from-top-3 duration-200">
                <span className="block text-[9px] uppercase font-bold tracking-widest text-slate-400 dark:text-slate-500 pl-1">
                  Matched Content Strings
                </span>
                <div className="text-[10px] font-mono leading-relaxed text-slate-650 dark:text-slate-350 space-y-2">
                  {searchResults.map((res, i) => (
                    <p key={i} className="bg-white p-2 rounded-xl border border-slate-100 dark:bg-slate-900 dark:border-slate-800 shadow-sm leading-normal">
                      {res}
                    </p>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* future pipeline chart explanation */}
          <div className="rounded-3xl border border-slate-200 bg-white p-6 dark:border-slate-800 dark:bg-slate-900 shadow-sm border-dashed">
            <h3 className="text-xs font-extrabold uppercase text-slate-450 dark:text-slate-500 tracking-wider mb-3 flex items-center gap-2">
              <Layers className="h-4 w-4 text-indigo-500" />
              System Architecture Diagram
            </h3>

            <div className="flex flex-col gap-3 font-mono text-[10px] text-slate-500 dark:text-slate-400 pl-1 leading-relaxed">
              <div className="p-2.5 rounded-xl bg-slate-50/50 border border-slate-100 dark:bg-slate-950/20 dark:border-slate-800 flex items-center justify-between gap-2 shadow-sm">
                <span className="font-bold flex items-center gap-1 text-slate-750 dark:text-slate-205">
                  <span className="h-2 w-2 rounded-full bg-indigo-500" /> 1. Upload Pool
                </span>
                <span className="text-[9px] text-slate-400">Extracts DOCX / PDF raw text</span>
              </div>
              <div className="flex justify-center my-0.5">
                <ArrowRight className="h-4 w-4 text-slate-300 rotate-90" />
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50/50 border border-slate-100 dark:bg-slate-950/20 dark:border-slate-800 flex items-center justify-between gap-2 shadow-sm">
                <span className="font-bold flex items-center gap-1 text-slate-750 dark:text-slate-205">
                  <span className="h-2 w-2 rounded-full bg-violet-500" /> 2. Gemini Embeddings
                </span>
                <span className="text-[9px] text-slate-400">Generate 768-D vectors</span>
              </div>
              <div className="flex justify-center my-0.5">
                <ArrowRight className="h-4 w-4 text-slate-300 rotate-90" />
              </div>

              <div className="p-2.5 rounded-xl bg-slate-50/50 border border-slate-100 dark:bg-slate-950/20 dark:border-slate-800 flex items-center justify-between gap-2 shadow-sm">
                <span className="font-bold flex items-center gap-1 text-slate-750 dark:text-slate-205">
                  <span className="h-2 w-2 rounded-full bg-emerald-500" /> 3. ChromaDB Context
                </span>
                <span className="text-[9px] text-slate-400">Local Vector Index Persistence</span>
              </div>
              <div className="flex justify-center my-0.5">
                <ArrowRight className="h-4 w-4 text-slate-300 rotate-90" />
              </div>

              <div className="p-2.5 bg-gradient-to-tr from-indigo-50/50 to-violet-50/50 dark:from-indigo-950/10 dark:to-violet-950/10 rounded-xl border border-indigo-100 dark:border-indigo-900/50 flex items-center justify-between gap-2 shadow-sm font-semibold">
                <span className="flex items-center gap-1 text-indigo-705 dark:text-indigo-400">
                  <Sparkles className="h-3.5 w-3.5" /> 4. Grounded AI Answer
                </span>
                <span className="text-[9px] text-indigo-600 dark:text-indigo-455">100% Hallucination Free</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
