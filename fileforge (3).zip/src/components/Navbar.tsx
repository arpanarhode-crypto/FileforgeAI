import { Sun, Moon, Monitor, FileCheck2 } from "lucide-react";
import { Theme, User, UsageLimits } from "../types";
import AccountMenu from "./AccountMenu";

interface NavbarProps {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  activePage: string;
  user: User | null;
  limits: UsageLimits | null;
  isOffline?: boolean;
  onLoginSuccess: (user: User, token: string) => void;
  onLogout: () => void;
  onRefreshLimits: () => void;
  onOpenUpgradeModal: () => void;
}

export default function Navbar({ 
  theme, 
  setTheme, 
  activePage,
  user,
  limits,
  isOffline = false,
  onLoginSuccess,
  onLogout,
  onRefreshLimits,
  onOpenUpgradeModal
}: NavbarProps) {
  return (
    <header className="sticky top-0 z-40 flex h-16 w-full items-center justify-between border-b border-slate-200 bg-white/85 px-6 backdrop-blur-md dark:border-slate-800 dark:bg-slate-900/85">
      <div className="flex items-center gap-3">
        <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-indigo-600 to-violet-500 text-white shadow-md shadow-indigo-100 dark:shadow-none animate-pulse">
          <FileCheck2 className="h-6 w-6 animate-spin" style={{ animationDuration: '6s' }} id="nav-logo-icon" />
        </div>
        <div>
          <h1 className="font-display text-lg font-black tracking-tight text-slate-850 dark:text-white flex items-center gap-2">
            FileForge
          </h1>
          <p className="hidden text-[10px] uppercase font-bold text-slate-400 dark:text-slate-500 sm:block tracking-widest leading-none">
            Universal AI Tool Forge
          </p>
        </div>
      </div>

      <div className="flex items-center gap-4">
        {isOffline && (
          <div className="hidden items-center gap-2 rounded-full bg-rose-50 border border-rose-200/60 px-3 py-1.5 text-xs text-rose-600 dark:bg-rose-950/40 dark:border-rose-900/40 dark:text-rose-400 md:flex font-extrabold shadow-sm animate-pulse">
            <span className="h-2 w-2 rounded-full bg-rose-500" />
            <span>Offline Local Mode</span>
          </div>
        )}

        {/* Beautiful Segmented Theme Switcher */}
        <div className="flex items-center rounded-xl bg-slate-100/80 p-1 dark:bg-slate-800/80 border border-slate-200/50 dark:border-slate-750">
          <button
            onClick={() => setTheme("light")}
            className={`flex h-7 w-7 items-center justify-center rounded-lg transition-all cursor-pointer ${
              theme === "light"
                ? "bg-white text-indigo-600 shadow-sm dark:bg-slate-950"
                : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300"
            }`}
            title="Light Theme"
          >
            <Sun className="h-4 w-4" />
          </button>
          
          <button
            onClick={() => setTheme("dark")}
            className={`flex h-7 w-7 items-center justify-center rounded-lg transition-all cursor-pointer ${
              theme === "dark"
                ? "bg-white text-indigo-600 shadow-sm dark:bg-slate-950 dark:text-indigo-400"
                : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300"
            }`}
            title="Dark Theme"
          >
            <Moon className="h-4 w-4" />
          </button>

          <button
            onClick={() => setTheme("system")}
            className={`flex h-7 w-7 items-center justify-center rounded-lg transition-all cursor-pointer ${
              theme === "system"
                ? "bg-white text-indigo-600 shadow-sm dark:bg-slate-950 dark:text-indigo-400"
                : "text-slate-500 hover:text-slate-700 dark:text-slate-400 dark:hover:text-slate-300"
            }`}
            title="System Preference"
          >
            <Monitor className="h-4 w-4" />
          </button>
        </div>

        {/* Elegant top email display */}
        {user && (
          <div className="hidden sm:flex items-center gap-2.5 border border-slate-200 bg-slate-50 rounded-2xl py-1 pl-3 pr-2.5 dark:border-slate-800 dark:bg-slate-950/40 shadow-sm">
            <div className="flex flex-col items-end leading-none space-y-0.5">
              <span className="text-xxs font-black text-slate-800 dark:text-slate-200 font-mono">
                {user.email}
              </span>
              <span className="text-[8px] font-black uppercase text-indigo-600 dark:text-indigo-400 font-sans tracking-widest block">
                VIP Premium
              </span>
            </div>
            <div className="h-6 w-6 rounded-full bg-gradient-to-tr from-indigo-600 to-violet-500 text-[10px] font-bold text-white flex items-center justify-center select-none shadow-sm">
              AC
            </div>
          </div>
        )}

        {/* Dynamic SaaS Profile dropdown */}
        <AccountMenu 
          user={user}
          limits={limits}
          onLoginSuccess={onLoginSuccess}
          onLogout={onLogout}
          onRefreshLimits={onRefreshLimits}
          onOpenUpgradeModal={onOpenUpgradeModal}
        />
      </div>
    </header>
  );
}
