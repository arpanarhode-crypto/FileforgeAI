import { useState, useEffect } from "react";
import { Page, ToastMessage, UploadedFile, Theme, User, UsageLimits, HistoryItem } from "./types";
import { apiFetch } from "./utils";
import Navbar from "./components/Navbar";
import Sidebar from "./components/Sidebar";
import HomeOverview from "./components/HomeOverview";
import DashboardLauncher from "./components/DashboardLauncher";
import PDFHub from "./components/PDFHub";
import OCRHub from "./components/OCRHub";
import AIHub from "./components/AIHub";
import TranslationStudio from "./components/TranslationStudio";
import UpgradeModal from "./components/UpgradeModal";
import FeedbackPopup from "./components/FeedbackPopup";

import KnowledgeBase from "./components/KnowledgeBase";
import DownloadCenter from "./components/DownloadCenter";
import HistoryPage from "./components/HistoryPage";
import SettingsPage from "./components/SettingsPage";

import AIChatWithPDF from "./components/AIChatWithPDF";
import ResumeAnalyzer from "./components/ResumeAnalyzer";
import SmartNotesGenerator from "./components/SmartNotesGenerator";
import BatchProcessor from "./components/BatchProcessor";
import AdminDashboard from "./components/AdminDashboard";
import PublicShareViewer from "./components/PublicShareViewer";

import { 
  Menu, 
  X, 
  Sparkles, 
  FolderSync, 
  Home, 
  LayoutGrid, 
  FileText, 
  ScanText, 
  BrainCircuit, 
  BellRing, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  HelpCircle,
  Languages,
  MessageSquare,
  Database,
  BookOpen,
  Award,
  Download,
  History,
  Settings
} from "lucide-react";

export default function App() {
  const [activePage, setActivePage] = useState<Page>("home");
  const [theme, setTheme] = useState<Theme>(() => {
    return (localStorage.getItem("fileforge-theme") as Theme) || "system";
  });
  const [mobileMenuOpen, setMobileMenuOpen] = useState<boolean>(false);
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Track preloaded documents streamed across tabs
  const [streamFile, setStreamFile] = useState<UploadedFile | null>(null);

  // SaaS auth states
  const [user, setUser] = useState<User | null>(() => {
    const saved = localStorage.getItem("fileforge-user");
    try {
      if (saved) return JSON.parse(saved);
    } catch (_) {}
    return {
      id: "aryanchoudhary7368",
      email: "aryanchoudhary7368@gmail.com",
      plan: "premium",
      createdAt: new Date().toISOString()
    };
  });

  const [token, setToken] = useState<string | null>(() => {
    return localStorage.getItem("fileforge-token") || "premium-early-access-token";
  });

  const [limits, setLimits] = useState<UsageLimits | null>(null);
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [upgradeModalOpen, setUpgradeModalOpen] = useState<boolean>(false);
  
  // Smart feedback wizard popup manager
  const [feedbackOpen, setFeedbackOpen] = useState<boolean>(false);
  const [feedbackTool, setFeedbackTool] = useState<string>("");

  // Real-time local offline mode status detection
  const [isOffline, setIsOffline] = useState<boolean>(() => !navigator.onLine);

  useEffect(() => {
    const handleOnlineStatus = () => {
      setIsOffline(false);
      addToast("System online. AI cloud pipelines activated.", "success");
    };
    const handleOfflineStatus = () => {
      setIsOffline(true);
      addToast("System offline. Switched to secure Local Mode.", "info");
    };

    window.addEventListener("online", handleOnlineStatus);
    window.addEventListener("offline", handleOfflineStatus);

    return () => {
      window.removeEventListener("online", handleOnlineStatus);
      window.removeEventListener("offline", handleOfflineStatus);
    };
  }, []);

  // Synchronize CSS class for dark/light/system mode on the document body
  useEffect(() => {
    const handleThemeChange = () => {
      let isDark = false;
      if (theme === "system") {
        isDark = window.matchMedia("(prefers-color-scheme: dark)").matches;
      } else {
        isDark = theme === "dark";
      }

      if (isDark) {
        document.body.classList.add("dark");
      } else {
        document.body.classList.remove("dark");
      }
    };

    handleThemeChange();
    localStorage.setItem("fileforge-theme", theme);

    if (theme === "system") {
      const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
      mediaQuery.addEventListener("change", handleThemeChange);
      return () => mediaQuery.removeEventListener("change", handleThemeChange);
    }
  }, [theme]);

  // Handle toast dynamic removals
  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  const checkFeedbackCooldown = (): boolean => {
    const lastSubStr = localStorage.getItem("fileforge-last-feedback-submitted");
    const lastSkipStr = localStorage.getItem("fileforge-last-feedback-skipped");
    const now = new Date();

    if (lastSubStr) {
      try {
        const lastSub = new Date(lastSubStr);
        const diffTime = Math.abs(now.getTime() - lastSub.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays <= 7) return true; // Cooldown 7 days
      } catch (_) {}
    }

    if (lastSkipStr) {
      try {
        const lastSkip = new Date(lastSkipStr);
        const diffTime = Math.abs(now.getTime() - lastSkip.getTime());
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays <= 3) return true; // Cooldown 3 days
      } catch (_) {}
    }

    return false;
  };

  const addToast = (message: string, type: ToastMessage["type"] = "success") => {
    const id = Math.random().toString(36).substring(2, 9);
    setToasts((prev) => [...prev, { id, message, type }]);
    
    // Auto-remove after 3.5 seconds
    setTimeout(() => {
      removeToast(id);
    }, 3500);

    // Dynamic Feedback interceptor triggered on generic success outcomes
    if (type === "success") {
      const isCooldown = checkFeedbackCooldown();
      if (!isCooldown) {
        let toolName = "Document AI Tools";
        const msg = message.toLowerCase();
        
        if (msg.includes("word") || msg.includes("docx")) {
          toolName = "Word PDF Converter";
        } else if (msg.includes("merge") || msg.includes("join")) {
          toolName = "PDF Joiner Merge";
        } else if (msg.includes("split")) {
          toolName = "PDF Page Splitter";
        } else if (msg.includes("compress") || msg.includes("shrink")) {
          toolName = "PDF Compression Studio";
        } else if (msg.includes("ocr") || msg.includes("scan") || msg.includes("extract")) {
          toolName = "Vision OCR Scanner";
        } else if (msg.includes("translat")) {
          toolName = "Indian Translation Studio";
        } else if (msg.includes("summar")) {
          toolName = "AI Document Summarizer";
        } else if (msg.includes("note") || msg.includes("card") || msg.includes("mcq")) {
          toolName = "Smart Study Notes";
        } else if (msg.includes("resume") || msg.includes("ats")) {
          toolName = "Resume ATS Reviewer";
        } else if (msg.includes("chat")) {
          toolName = "AI Chat Desk";
        } else if (msg.includes("download") || msg.includes("export")) {
          toolName = "File Download Center";
        }

        setTimeout(() => {
          setFeedbackTool(toolName);
          setFeedbackOpen(true);
        }, 900);
      }
    }
  };

  const fetchUsageLimits = async () => {
    try {
      const res = await apiFetch("/api/usage");
      const data = await res.json();
      if (data.success && data.limits) {
        setLimits(data.limits);
      }
    } catch (err) {
      console.error("Failed to fetch limits:", err);
    }
  };

  const fetchUserHistory = async () => {
    try {
      const res = await apiFetch("/api/user-history");
      const data = await res.json();
      if (data.success && data.history) {
        setHistory(data.history);
      }
    } catch (err) {
      console.error("Failed to fetch history:", err);
    }
  };

  // Synchronous and reactive limits loader
  useEffect(() => {
    fetchUsageLimits();
    fetchUserHistory();
  }, [token]);

  // Handle custom API event signals safely
  useEffect(() => {
    const handleLimitExceeded = (e: Event) => {
      const customEvent = e as CustomEvent;
      setUpgradeModalOpen(true);
      addToast(customEvent.detail?.message || "Limits exceeded. Upgrade to Premium to unlock!", "error");
    };

    const handleApiSuccess = () => {
      setTimeout(() => {
        fetchUsageLimits();
        fetchUserHistory();
      }, 450);
    };

    window.addEventListener("api-limit-exceeded", handleLimitExceeded);
    window.addEventListener("api-success", handleApiSuccess);

    return () => {
      window.removeEventListener("api-limit-exceeded", handleLimitExceeded);
      window.removeEventListener("api-success", handleApiSuccess);
    };
  }, []);

  // Handle logging in
  const handleLoginSuccess = (newUser: User, newToken: string) => {
    setUser(newUser);
    setToken(newToken);
    localStorage.setItem("fileforge-user", JSON.stringify(newUser));
    localStorage.setItem("fileforge-token", newToken);
    addToast(`Greetings! Access granted as ${newUser.email}.`, "success");
  };

  // Handle log out
  const handleLogout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem("fileforge-user");
    localStorage.removeItem("fileforge-token");
    addToast("Logged out from AI forge session.", "info");
  };

  const handleUpgradeSuccess = (newPlan: 'premium') => {
    if (user) {
      const updated = { ...user, plan: newPlan };
      setUser(updated);
      localStorage.setItem("fileforge-user", JSON.stringify(updated));
    }
    fetchUsageLimits();
    addToast("Your account has been promoted to Premium Pro!", "success");
  };

  // Cross-workspace document stream action helper
  const handleDocStreamToAI = (file: UploadedFile) => {
    setStreamFile(file);
    setActivePage("ai-tools");
    addToast(`Transmitted "${file.name}" context into AI Summarizer!`, "info");
  };

  const showAIWorkspace = false; // Flag to enable/disable AI Assistant Workspace public rendering

  // Helper menu definition for mobile drawer list
  const navItemsMobileRaw = [
    { id: "home", label: "Overview", icon: Home },
    { id: "pdf-tools", label: "PDF Tools", icon: FileText },
    { id: "ocr-tools", label: "Vision OCR", icon: ScanText },
    { id: "translation-tools", label: "AI Translation", icon: Languages },
    { id: "pdf-chat", label: "AI Chat Desk", icon: MessageSquare },
    { id: "knowledge-base", label: "Knowledge Base", icon: Database },
    { id: "smart-notes", label: "Notes Generator", icon: BookOpen },
    { id: "resume-analyzer", label: "Resume Analyzer", icon: Award },
    { id: "download-center", label: "Downloads", icon: Download },
    { id: "history", label: "History Logs", icon: History },
    { id: "settings", label: "Settings", icon: Settings },
  ];

  const aiWorkspaceIds = ["pdf-chat", "knowledge-base", "smart-notes", "resume-analyzer"];
  const navItemsMobile = navItemsMobileRaw.filter(item => showAIWorkspace || !aiWorkspaceIds.includes(item.id));

  if (window.location.pathname.startsWith("/share/")) {
    return <PublicShareViewer />;
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 dark:bg-[#0b0f19] dark:text-slate-100 transition-colors duration-300">
      
      {/* Prime Header element */}
      <Navbar 
        theme={theme} 
        setTheme={setTheme} 
        activePage={activePage} 
        user={user}
        limits={limits}
        isOffline={isOffline}
        onLoginSuccess={handleLoginSuccess}
        onLogout={handleLogout}
        onRefreshLimits={fetchUsageLimits}
        onOpenUpgradeModal={() => setUpgradeModalOpen(true)}
      />

      {/* Top Mobile navigational subheader */}
      <div className="flex h-12 w-full items-center justify-between border-b border-slate-200/80 bg-white/50 px-4 dark:border-slate-800 dark:bg-slate-900/50 md:hidden">
        <div className="flex items-center gap-2">
          <FolderSync className="h-4 w-4 text-indigo-505 animate-spin" style={{ animationDuration: '8s' }} />
          <span className="text-xs font-semibold capitalize font-display text-slate-800 dark:text-slate-200">
            {activePage === "home" ? "Welcome" : activePage.replace("-", " ")}
          </span>
        </div>

        <button
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="flex h-8 w-8 items-center justify-center rounded-lg border border-slate-200 bg-white text-slate-600 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400 cursor-pointer animate-pulse"
          id="mobile-menu-toggle"
        >
          {mobileMenuOpen ? (
            <X className="h-4 w-4" />
          ) : (
            <Menu className="h-4 w-4" />
          )}
        </button>
      </div>

      {/* Main viewport segment */}
      <div className="flex-1 flex max-w-[1600px] w-full mx-auto relative">
        
        {/* Elegant sidebar navigation */}
        <Sidebar activePage={activePage} setActivePage={setActivePage} />

        {/* Mobile Navigation Drawer Dropdown */}
        {mobileMenuOpen && (
          <div className="absolute inset-x-0 top-0 z-30 border-b border-slate-200 bg-white p-4 shadow-lg dark:border-slate-800 dark:bg-[#0d1222] md:hidden animate-in fade-in slide-in-from-top duration-250">
            <span className="block text-xxs font-mono font-bold text-slate-400 dark:text-slate-500 uppercase tracking-wider mb-2">
              Menu Drawer
            </span>
            <div className="grid grid-cols-2 gap-2">
              {navItemsMobile.map((item) => {
                const Icon = item.icon;
                const isSelected = activePage === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActivePage(item.id as Page);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex items-center gap-2 rounded-xl p-3 text-xs font-semibold uppercase tracking-wider cursor-pointer ${
                      isSelected
                        ? "bg-indigo-600 text-white shadow-sm"
                        : "bg-slate-50 text-slate-600 hover:bg-slate-100 dark:bg-slate-950 dark:text-slate-400 dark:hover:bg-slate-900"
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span>{item.label.split(" ")[0]}</span>
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Principal Dynamic Module Viewport Container */}
        <main className="flex-1 p-6 md:p-8 overflow-y-auto max-w-full">
          <div className="max-w-5xl mx-auto space-y-6">
            
            {activePage === "home" && (
              <HomeOverview onNavigate={(pg) => setActivePage(pg)} />
            )}

            {activePage === "dashboard" && (
              <DashboardLauncher 
                user={user}
                limits={limits}
                history={history}
                onNavigate={(pg) => setActivePage(pg)} 
                onOpenUpgradeModal={() => setUpgradeModalOpen(true)}
                onRefreshLimits={fetchUsageLimits}
              />
            )}

            {activePage === "pdf-tools" && (
              <PDFHub onAddToast={addToast} />
            )}

            {activePage === "ocr-tools" && (
              <OCRHub onAddToast={addToast} />
            )}

            {activePage === "translation-tools" && (
              <TranslationStudio onAddToast={addToast} isOffline={isOffline} />
            )}

            {activePage === "ai-tools" && (
              <AIHub 
                onAddToast={addToast} 
                preloadedFile={streamFile}
                onClearPreload={() => setStreamFile(null)}
              />
            )}

            {activePage === "pdf-chat" && (
              <AIChatWithPDF onAddToast={addToast} />
            )}

            {activePage === "resume-analyzer" && (
              <ResumeAnalyzer onAddToast={addToast} />
            )}

            {activePage === "smart-notes" && (
              <SmartNotesGenerator onAddToast={addToast} />
            )}

            {activePage === "batch-process" && (
              <BatchProcessor onAddToast={addToast} />
            )}

            {activePage === "knowledge-base" && (
              <KnowledgeBase onAddToast={addToast} />
            )}

            {activePage === "download-center" && (
              <DownloadCenter onAddToast={addToast} />
            )}

            {activePage === "history" && (
              <HistoryPage onAddToast={addToast} onNavigate={setActivePage} />
            )}

            {activePage === "settings" && (
              <SettingsPage 
                theme={theme} 
                onThemeChange={setTheme} 
                onAddToast={addToast} 
              />
            )}

            {activePage === "admin-dashboard" && (
              <AdminDashboard />
            )}
          </div>
        </main>
      </div>

      {/* Floating dynamic slide-out toast system container */}
      <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-2.5 max-w-sm pointer-events-none">
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-3 rounded-2xl p-4 shadow-lg ring-1 transition-all duration-300 transform translate-y-0 animate-in fade-in slide-in-from-bottom-5 ${
              toast.type === "success"
                ? "bg-emerald-58 border-emerald-100 ring-emerald-500/10 text-emerald-950 dark:bg-emerald-950/90 dark:border-emerald-900 dark:ring-emerald-400/20 dark:text-emerald-100"
                : toast.type === "error"
                ? "bg-rose-58 border-rose-100 ring-rose-500/10 text-rose-950 dark:bg-rose-950/90 dark:border-rose-900 dark:ring-rose-400/20 dark:text-rose-100"
                : "bg-white border-slate-200 ring-indigo-500/10 text-slate-900 dark:bg-slate-900 dark:border-slate-800 dark:text-slate-100"
            }`}
            id={`toast-card-${toast.id}`}
          >
            <div className="mt-0.5">
              {toast.type === "success" && <CheckCircle2 className="h-5 w-5 text-emerald-500 dark:text-emerald-400" />}
              {toast.type === "error" && <XCircle className="h-5 w-5 text-rose-500 dark:text-rose-400" />}
              {toast.type === "info" && <Sparkles className="h-5 w-5 text-indigo-500 dark:text-indigo-400" />}
            </div>
            
            <div className="flex-1 space-y-0.5">
              <p className="text-xs font-semibold leading-snug">
                {toast.type === "success" && "Operational Success"}
                {toast.type === "error" && "An Error Occurred"}
                {toast.type === "info" && "Workspace Notification"}
              </p>
              <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-normal font-medium">
                {toast.message}
              </p>
            </div>

            <button
              onClick={() => removeToast(toast.id)}
              className="text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 p-0.5 cursor-pointer flex-shrink-0"
              title="Close toast"
            >
              <X className="h-3.5 w-3.5" />
            </button>
          </div>
        ))}
      </div>

      {/* Structured SaaS Premium Upgrade Modal popup widget */}
      <UpgradeModal 
        isOpen={upgradeModalOpen}
        onClose={() => setUpgradeModalOpen(false)}
        onUpgradeSuccess={handleUpgradeSuccess}
      />

      {/* Smart rating & feedback system modal popup */}
      <FeedbackPopup
        isOpen={feedbackOpen}
        onClose={() => setFeedbackOpen(false)}
        toolUsed={feedbackTool}
        onAddToast={addToast}
      />

      {/* Styled minimalistic subtle credits brand segment */}
      <footer className="w-full text-center py-4 bg-slate-105 border-t border-slate-200/80 dark:bg-slate-950/50 dark:border-slate-850">
        <p className="text-xxs font-mono text-slate-400 dark:text-slate-500 uppercase tracking-widest flex items-center justify-center gap-1.5 leading-none">
          <HelpCircle className="h-3.5 w-3.5" />
          <span>FileForge Document Systems • Version 1.0.0</span>
        </p>
      </footer>
    </div>
  );
}
