const { contextBridge, ipcRenderer } = require("electron");

// Clean context bridge to prevent XSS vulnerability access to standard Node APIs
contextBridge.exposeInMainWorld("electronAPI", {
  openFileDialog: (options) => ipcRenderer.invoke("dialog:openFile", options || {}),
  saveFileDialog: (defaultName, base64) => ipcRenderer.invoke("dialog:saveFile", { defaultName, base64 }),
  getOfflineStatus: () => ipcRenderer.invoke("app:getOfflineStatus"),
  
  // Custom listeners for native app menu communications
  onNavigateTo: (callback) => ipcRenderer.on("navigate-to", (event, page) => callback(page)),
  onShowAbout: (callback) => ipcRenderer.on("show-about", (event) => callback())
});
